class VehicleNotFound(Exception):
    pass


class InvalidSlot(Exception):
    pass

class PricesAlreadyAdded(Exception):
    pass